#include <sys/io.h>
#include <math.h>
int main()
{
	float tc;
	outb_p(inb_p(0x61)|3,0x61);
	tc=1193180/10000;
	//outb_p(0xb6,0x43);
	//outb_p(tc&0xff,0x42);
	//outb_p((tc>>8)&0xff,0x42);
	return 0;
}
