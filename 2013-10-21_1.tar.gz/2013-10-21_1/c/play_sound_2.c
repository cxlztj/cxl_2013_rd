#include <sys/soundcard.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

main()
{
	int id,fd,i,j;
	char testbuf[4096],filebuf[4096];

//	if((id =open("/dev/audio", O_RDWR))<0) 
	if((id =open("/dev/snd", O_RDWR))<0)
	{
		fprintf(stderr," Can't open sound device!\n");
		exit(-1);
	}

	if((fd=open("test.wav",O_RDWR))<0)
	{
		fprintf(stderr," Can't open output file!\n");
		exit(-1);
	}

	i=0;
	ioctl (id,SNDCTL_DSP_RESET,(char *)&i) ;
	ioctl (id,SNDCTL_DSP_SYNC,(char *)&i);
	i=1;
	ioctl (id,SNDCTL_DSP_NONBLOCK,(char *)&i);
	i=8000;
	ioctl (id,SNDCTL_DSP_SPEED,(char *)&i);
	i=1;
	ioctl (id,SNDCTL_DSP_CHANNELS,(char *)&i);
	i=8;
	ioctl (id,SNDCTL_DSP_SETFMT,(char *)&i);
	i=3;
	ioctl (id,SNDCTL_DSP_SETTRIGGER,(char *)&i);
	i=3;
	ioctl (id,SNDCTL_DSP_SETFRAGMENT,(char *)&i);
	i=1;
	ioctl (id,SNDCTL_DSP_PROFILE,(char *)&i);

	for(j=0;j<10;)
	{
		i=read(id,testbuf,4096);
		if(i>0)
		{
			write(fd,filebuf,i);
			j++;
		}
	}

	close(fd);
	close(id);
}

