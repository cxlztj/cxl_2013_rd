#include <linux/init.h>
#include <linux/delay.h>
#include <linux/module.h>
#include <linux/ioport.h>
#include <linux/netdevice.h>
#include <linux/etherdevice.h>
#include <linux/skbuff.h>
#include <linux/version.h>
#include <asm/dma.h>
#include <linux/spinlock.h>
#include <linux/crc32.h>
#include <linux/mii.h>
#include <linux/ethtool.h>
#include <asm/uaccess.h>



struct net_device *dev = NULL;


static struct net_device_ops privdev_ops;
 
//{
    //.ndo_init        = privdev_init,
    //.ndo_uninit        = privdev_uninit,
    //.ndo_open        = privdev_open,
   // .ndo_stop        = privdev_stop,
 //   .ndo_start_xmit        = virtnet_start_xmit,
   // .ndo_validate_addr    = eth_validate_addr,
   // .ndo_do_ioctl        = privdev_ioctl,
   // .ndo_set_mac_address    = privdev_set_mac_address,
   // .ndo_neigh_setup    = privdev_neigh_setup,
  //  .ndo_get_stats        = privdev_get_stats,
   // .ndo_set_rx_mode    = privdev_rx_mode,
//};

static int virtnet_start_xmit(struct sk_buff *skb, struct net_device *dev)

{

       printk("send %d bytes\n", skb->len);

        
       
        dev->stats.tx_packets++;
	

        dev->stats.tx_bytes += skb->len;

        return 0;

}



static int __init virtnet_init(void)

{

        

        dev = alloc_netdev(0, "virtnet%d", ether_setup);

        dev->netdev_ops        = &privdev_ops;

        //dev->hard_start_xmit = &virtnet_start_xmit;
        privdev_ops.ndo_start_xmit=&virtnet_start_xmit;
        
        dev->dev_addr[0] = 0x00;

        dev->dev_addr[0] = 0x12;

        dev->dev_addr[0] = 0x34;

        dev->dev_addr[0] = 0x56;

        dev->dev_addr[0] = 0x78;

        dev->dev_addr[0] = 0x9a;

        

        register_netdev(dev);

        return 0;

}

 



static void __exit virtnet_exit(void)

{

        unregister_netdev(dev);

        free_netdev(dev);

        return;

}

 



module_init(virtnet_init);

module_exit(virtnet_exit);

MODULE_LICENSE("GPL");
