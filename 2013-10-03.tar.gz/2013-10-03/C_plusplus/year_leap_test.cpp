#include "iostream"
using namespace std;

int main(void)
{
	int year;
	bool is_leap_year;

	cout << "Enter the year: ";
	cin >> year;
	is_leap_year=((year % 4 ==0 && year % 100 !=0) || (year % 400 ==0));
	if(is_leap_year)
		cout << year << " is a leap year" << endl;
	else
		cout << year << " is not a leap year" << endl;
}
