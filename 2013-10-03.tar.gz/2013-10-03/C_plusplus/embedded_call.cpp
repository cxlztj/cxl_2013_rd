#include "iostream"
using namespace std;

int fun1(int x,int y);
int fun2(int m);

int main()
{
	int a,b;
	cin>>a>>b;
	cout<<"a,b的平方和:"<<fun1(a,b)<<endl;
}

int fun1(int x,int y)
{
	return(fun2(x)+fun2(y));
}

int fun2(int m)
{
	return(m*m);
}

