#include "iostream"
using namespace std;

inline double calarea(double radius)
{
	return 3.14*radius*radius;
}

int main()
{
	double r(3.0);
	double area;
	area=calarea(r);
	cout<<area<<endl;
}

