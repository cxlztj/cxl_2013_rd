#include "stdio.h"
#include "string.h"

struct data
{
	int count;
	int free;
	int key;
	char value[30];
};

void init(struct data d[],int n)
{
	int i;
	for(i=0;i<n;i++)
	{
		d[i].count=0;
		d[i].free=1;
		d[i].key=0;
		strcpy(d[i].value,"");
	}
}


void print(struct data d[],int n)
{
	int i;
	printf("count,free,key,value\n");
	for(i=0;i<n;i++)
	{
		printf(" %-4d %-4d %-4d %-5s\n",d[i].count,d[i].free,d[i].key,d[i].value);
	}
}




void add(struct data d[],int key,char value[]) 
{
	int flag=1;
	int addr=hash(key);
	d[addr].count+=1;
        while(flag) 
	{
		if(d[addr].free==1) 
		{
			d[addr].free=0;
			d[addr].key=key;
			strcpy(d[addr].value,value);
			printf("------Add Success!------");
			flag=0;
		}
		else
		{
			flag=1;
			addr+=1;
			if(addr>=20)
			{
				printf("------out of space!------\n");
				return;
			}
		}
	}
}



int hash(int key)
{
	return key%50;
}


int findbykey(struct data d[],int key)
{
	int addr=hash(key);
	int count=d[addr].count;
	if(count==0)
	{
		printf("-------No Record!--------");
		return 0;
	}
	else
	{
		int flag=1;
		while(flag)
		{
			if(d[addr].free==1)
			{
				flag=1;
				addr+=1;
				if(addr>=20)
				{
					printf("------No Record!--------");
					return 0;
				}
				else
				{
					int key1=d[addr].key;
					if(key==key1)
					{
						flag=0;
						return addr;
					}
					else
					{
						if(hash(key)==hash(key1))
						{
							count-=1;
							if(count==0)
							{
								printf("--------No Record!-------");
								return 0;
							}
							else
							{
								flag=1;
								addr+=1;
								if(addr>=20)
								{
									printf("--------No record!--------");
									return 0;
								}
							}
						}
						else
						{
							flag=1;
							addr+=1;
							if(addr>=20)
							{
								printf("--------No record!--------");
								return 0;
							}
						}
					}
				}
			}
		}
	}

}


int deletebykey(struct data d[],int key)
{
	int rs,addr;
	rs=findbykey(d,key);
	addr=hash(key);
	if(rs>0)
	{
		d[rs].free=1;
		d[addr].count-=1;
		return rs;
	}
	else
	{
		printf("------No Record!-----");
		return -1;
	}
}


void start()
{
	printf("-----------Please choose------------\n");
	printf("A---Add a new record\n");
	printf("F---find the record by key\n");
	printf("D---Delete the record by key\n");
	printf("S---Show the records\n");
	printf("E---Exit\n");
}



void addrecord(struct data d[])
{
	int key;
	char value[30];
	printf("Please input the key and the value!\n");
	scanf("%d,%s",&key,&value);
	printf("Your input :key=%d,value=%s\n",key,value);
	getchar();
	add(d,key,value);
	printf("\n");
}



void find(struct data d[])
{
	int addr,key;
	printf("Please input the key:\n");
	scanf("%d",&key);
	getchar();
	addr=findbykey(d,key);
	if(addr>0)
	{
		printf("Find Success!the key =%d,the value=%s\n",d[addr].key,d[addr].value);
	}
	else
	{
		printf("Find Failure!\n");
	}
	printf("\n");
}

void delete(struct data d[])
{
	int key,rs;
	printf("Please input the key:\n");
	scanf("%d",&key);
	getchar();
	rs=deletebykey(d,key);
	if(rs>0)
	{
		printf("Delete Success!the key is :%d\n",d[rs].key);
	}
	else
	{
		printf("Delete Failure!\n");
	}
}


int main(void)
{
	char o;
	int addr,key;
	struct data d[20];
	init(d,20);
	do 
	{
		start();
		scanf("%c",&o);
		getchar();

		if(o=='A'||o=='a')
		{
			addrecord(d);
		}
		else
		if(o=='F'||o=='f')
		{
			find(d);
		}
		else
		if(o=='D'||o=='d')
		{
			delete(d);
		}
		else
		if(o=='E'||o=='e')
		{
			return 0;
		}
		else
		if(o=='S'||o=='s')
		{
			print(d,20);
		}
		else
		{
			printf("Error!Please input again!\n");
		}
	}
	while(!(o=='E'||o=='e'));
}



























