#include "stdio.h"
#include "sys/types.h"
#include "stdlib.h"
#include "fcntl.h"

int main()
{
	int fd[2],cld_pid,status;
	char buf[200],len;

	if(pipe(fd)==-1)
	{
		printf("create pipe error ");
		exit(1);
	}
	if((cld_pid=fork())==0)
	{
		close(fd[1]);     //child process close write_pipe
                len=read(fd[0],buf,sizeof(buf));
                buf[len]=0;
                printf("Child read pipe is -- [%s]  \n",buf);
		exit(0);
	}
        else
	{
		close(fd[0]);     //parent process close read_pipe
		sprintf(buf,"Parent create this buff for child %d  ",cld_pid);
                write(fd[1],buf,strlen(buf));                
		exit(0);
	}
}
			









