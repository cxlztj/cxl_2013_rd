#include "stdio.h"

int main()
{
	int pid;
	pid=fork();
	if(pid==0)
	{
		printf("I am the child,my pid is %d!\n",getpid());
	}
	else
	{
		printf("I am the parent,my pid is %d,my child pid is %d!\n",getpid(),pid);
	}
}
