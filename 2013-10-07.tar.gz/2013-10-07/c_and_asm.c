#include "stdio.h"
int main()
{
	int a=10;
        
//	__asm__ __volatile__("movl %eax,%ebx\n\t"
//			     "movb %bh,(%eax)");
	__asm__ __volatile__("movl %eax,1");

	printf("a=%d\n",a);
}
