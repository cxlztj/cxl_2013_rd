#include <stdio.h>
#include <stdlib.h>

extern void writeHexASCII(char *buffer,unsigned int number);
extern unsigned int swapEnds(unsigned int x);

int main(int arg_c, char **arg_v)
{
    int i;
    unsigned int num, num_swap;
    char buf[16];

    if(arg_c < 2)
    {
  fprintf(stderr, "Usage: %s NUM1 NUM2 NUM3.../n", arg_v[0]);
  return -1;
    }

    i = 1;
    while(i < arg_c)
    {
  num = atoi(arg_v[i]);
  num_swap = swapEnds(num);

  fprintf(stdout, "%d: ", num);
  writeHexASCII(buf, num);
  fprintf(stdout, "%s <-> ", buf);
  writeHexASCII(buf, num_swap);
  fprintf(stdout, "%s = ", buf);
  fprintf(stdout, "%d/n", num_swap);

  i++;
    }

    return 0;
}

