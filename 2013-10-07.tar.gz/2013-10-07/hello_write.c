void write_string(char * pstring,int color)
{
	char *pvideo=(char * )0xB8000000;
	while(*pstring)
	{
		*pvideo=*pstring;
		pstring++;
		pvideo++;
		*pvideo=color;
		pvideo++;
	}
}

int main()
{
	
	write_string("Hello,world!",4);	
}
