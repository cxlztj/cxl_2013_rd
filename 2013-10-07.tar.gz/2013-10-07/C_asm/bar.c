//bar.c                                                                                                                                                      
void myprint(char* msg  , int len);

int choose(int a,int b)
{
    //printf("a=%d  b=%d  \n",a,b);
    if ( a>=b )
        myprint("the 1st one\n",13);
    else
        myprint("the 2st one\n",13);
    return 0;
}
