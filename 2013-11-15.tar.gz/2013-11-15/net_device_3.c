#include <linux/config.h>
#ifdef LINUX_CONFIG_H
#define LINUX_CONFIG_H
#include <linux/autoconf.h>
#endif
#include <linux/module.h>
#include <linux/init.h>
#include <linux/moduleparam.h>


u8 *tx_packetdata;
struct sk_buff *skb;
spinlock_t lock;
     
struct napi_struct napi;
struct net_device *dev;

 
static void snull_tx_timeout(struct net_device *dev);

 /*
  * The poll implementation.
  */ 


static int snull_poll(struct net_device *dev, int *budget)
static int snull_poll(struct napi_struct *napi, int budget)
{
	int npackets = 0, quota = min(dev->quota, *budget);
	int npackets = 0, quota = budget;
	struct sk_buff *skb;
	struct snull_priv *priv = netdev_priv(dev);
	struct snull_priv *priv = container_of(napi,struct snull_priv,napi);
	struct net_device *dev=priv->dev;
  struct snull_packet *pkt;
    
  while (npackets < quota && priv->rx_queue) {

   snull_release_buffer(pkt);
  }
  /* If we processed all packets, we're done; tell the kernel and reenable ints */
	*budget -= npackets;
	dev->quota -= npackets;
  if (! priv->rx_queue) {
  	netif_rx_complete(dev);
		napi_complete(&priv->napi);
   	snull_rx_ints(dev, 1);
   	return 0;
  }

  priv->status = 0;
  if (statusword & SNULL_RX_INTR) {
   snull_rx_ints(dev, 0);  /* Disable further interrupts */
   netif_rx_schedule(dev);
	  napi_schedule(&priv->napi);
  }
  if (statusword & SNULL_TX_INTR) {
          /* a transmission is over: free the skb */

 
 
 int snull_header(struct sk_buff *skb, struct net_device *dev,
                unsigned short type, void *daddr, void *saddr,
                unsigned int len)
                unsigned short type, const void *daddr, const void *saddr,
                unsigned len)
 {
  struct ethhdr *eth = (struct ethhdr *)skb_push(skb,ETH_HLEN);
 

  /* The init function (sometimes called probe).
  * It is invoked by register_netdev()
  */

static const struct net_device_ops snull_dev_ops = {

 .ndo_open  =snull_open,
 .ndo_stop  =snull_release,
 .ndo_set_config =snull_config,
 .ndo_start_xmit =snull_tx,
 .ndo_do_ioctl =snull_ioctl,
 .ndo_get_stats =snull_stats,
 .ndo_change_mtu =snull_change_mtu,
 .ndo_tx_timeout =snull_tx_timeout,
};
 
static const struct header_ops snull_header_ops= {
 .create =snull_header,
 .rebuild =snull_rebuild_header,
 .cache = NULL,             /* Disable caching */
};
 
 void snull_init(struct net_device *dev)
 {
  struct snull_priv *priv;

   
  ether_setup(dev); /* assign some of the fields */
 
	dev->open            = snull_open;
	dev->stop            = snull_release;
	dev->set_config      = snull_config;
	dev->hard_start_xmit = snull_tx;
	dev->do_ioctl        = snull_ioctl;
	dev->get_stats       = snull_stats;
	dev->change_mtu      = snull_change_mtu; 
	dev->rebuild_header  = snull_rebuild_header;
	dev->hard_header     = snull_header;
	dev->tx_timeout      = snull_tx_timeout;
	dev->netdev_ops = &snull_dev_ops;
	dev->header_ops = &snull_header_ops;
  dev->watchdog_timeo = timeout;
	 if (use_napi) {
	  dev->poll        = snull_poll;
	  dev->weight      = 2;
 }

  /* keep the default flags, just add NOARP */
  dev->flags           |= IFF_NOARP;
  dev->features        |= NETIF_F_NO_CSUM;
 dev->hard_header_cache = NULL;      /* Disable caching */
 
  /*
   * Then, initialize the priv field. This encloses the statistics

   */
  priv = netdev_priv(dev);
  memset(priv, 0, sizeof(struct snull_priv));
	 priv->dev = dev;
	
  spin_lock_init(&priv->lock);
  snull_rx_ints(dev, 1);  /* enable receive interrupts */
  snull_setup_pool(dev);
	 if (use_napi) {
	  netif_napi_add(dev,&priv->napi,snull_poll,2);
	 }

 } 

