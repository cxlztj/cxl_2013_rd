#include <linux/module.h>
#include <linux/init.h>
#include <linux/moduleparam.h>
#include <linux/netdevice.h>
#include <linux/etherdevice.h>
#include <linux/kernel.h>
#include <linux/interrupt.h>
#include <linux/spinlock.h>
#include <linux/sched.h>
#include <linux/slab.h>
#include <linux/errno.h>
#include <linux/types.h>
#include <linux/in.h>
#include <linux/ip.h>
#include <linux/tcp.h>
#include <linux/skbuff.h>
#include <asm/checksum.h>

#define SNULL_RX_INTR    1UL
#define SNULL_TX_INTR    2UL
#define SNULL_TIMEOUT    5

MODULE_AUTHOR("xishuai");
MODULE_LICENSE("GPLv3");

int pool_size = 8;
module_param(pool_size, int, 0);
int use_napi = 0;
module_param(use_napi, int, 0);

struct snull_packet 
{
	struct snull_packet *next;
	struct net_device *dev;
	int datalen;
	u8 data[ETH_DATA_LEN];
};

struct snull_priv 
{
	struct net_device_stats stats;
	int status;
	struct snull_packet *ppool;
	struct snull_packet *rx_queue;
	int rx_int_enabled;
	int tx_packetlen;
	u8 *tx_packetdata;
	struct sk_buff *skb;
	spinlock_t lock;
	struct napi_struct *snull_napi;
};

static struct net_device *snull_dev[2];
static void(*snull_interrupt)(int, void*, struct pt_regs *);

static int snull_open(struct net_device *dev)
{
	printk(KERN_ALERT "snull_open\n");
	memcpy(dev->dev_addr, "\0SNUL0", ETH_ALEN);
	if(dev == snull_dev[1]) 
	{
		dev->dev_addr[ETH_ALEN -1]++;
	}
	netif_start_queue(dev);//�����ϲ����ndo_start_xmit����
	return 0;
}

static int snull_release(struct net_device *dev)
{
	printk("snullnet:snull_release\n");
	netif_stop_queue(dev);//��ֹ�ϲ���ñ��豸�ķ��ͺ���
	return 0;
}

static int snull_config(struct net_device *dev, struct ifmap *map)
{
	printk("snullnet:snull_config\n");
	if(dev->flags & IFF_UP) return -EBUSY;
	if(map->base_addr != dev->base_addr) 
	{
		printk(KERN_WARNING "snull: Can't change I/O address\n");
		return -EOPNOTSUPP;
	}
	if(map->irq != dev->irq) 
	{
		dev->irq = map->irq;
	}
	/*����������ĸı�*/
	return 0;
}

static void snull_enqueue_buf(struct net_device *dev, struct snull_packet *pkt)
{
	unsigned long flags;
	struct snull_priv *priv = netdev_priv(dev);
	printk("snullnet:snull_enqueue_buf\n");
	spin_lock_irqsave(&priv->lock, flags);
	pkt->next = priv->rx_queue;
	priv->rx_queue = pkt;
	spin_unlock_irqrestore(&priv->lock, flags);
}

static struct snull_packet *snull_get_tx_buffer(struct net_device *dev)
{
	struct snull_priv *priv = netdev_priv(dev);
	unsigned long flags;
	struct snull_packet *pkt;
	
	printk("snullnet:snull_get_tx_buffer\n");
	spin_lock_irqsave(&priv->lock, flags);
	pkt = priv->ppool;
	priv->ppool = pkt->next;

	if (priv->ppool == NULL) 
	{
		printk(KERN_INFO "pool empty\n");
		netif_stop_queue(dev);
	}
	spin_unlock_irqrestore(&priv->lock, flags);
	return pkt;
}

//�����ϲ����ݣ������������ײ�Ӳ��ϸ��
static void snull_hw_tx(char *buf, int len, struct net_device *dev)
{
	struct iphdr *ih;//
	struct net_device *dest;
	struct snull_priv *priv;
	u32 *saddr, *daddr;
	struct snull_packet *tx_buffer;
	
	ih = (struct iphdr *)(buf + sizeof(struct ethhdr));
	saddr = &ih->saddr;
	daddr = &ih->daddr;

	//�������޸���IP���ͷ���������������������ǲ�Ӧ�õ�
	((u8 *)saddr)[2] ^= 1;
	((u8 *)daddr)[2] ^= 1;
 	
 	ih->check = 0;    //Ҫ���¼���У���
	ih->check = ip_fast_csum((unsigned char *)ih, ih->ihl);

	//׼������
	dest = snull_dev[dev == snull_dev[0] ? 1 : 0];
	priv = netdev_priv(dest);
	tx_buffer = snull_get_tx_buffer(dev);
	tx_buffer->datalen = len;
	memcpy(tx_buffer->data, buf, len);
	snull_enqueue_buf(dest, tx_buffer);

	if(priv->rx_int_enabled) 
	{
		priv->status |= SNULL_RX_INTR;
		snull_interrupt(0, dest, NULL);
	}
	
	priv = netdev_priv(dev);
	priv->tx_packetlen = len;
	priv->tx_packetdata = buf;
	priv->status |= SNULL_TX_INTR;
	snull_interrupt(0, dev, NULL);//ԭ���Ĵ��������и�ģ�ⶪ���Ĵ����
}

static int snull_tx(struct sk_buff *skb, struct net_device *dev)
{
	int len;
	char *data, shortpkt[ETH_ZLEN];
	
	struct snull_priv *priv = netdev_priv(dev);
	printk("snullnet:snull_tx\n");

	data = skb->data;
	len = skb->len;
	if(len < ETH_ZLEN) 
	{
		memset(shortpkt, 0, ETH_ZLEN);
		memcpy(shortpkt, skb->data, skb->len);
		len = ETH_ZLEN;
		data = shortpkt;
	}
	
	dev->trans_start = jiffies;
	priv->skb = skb;
	snull_hw_tx(data, len, dev);//ʵ�ʵķ��͹��̣��豸���
	
	return 0;
}

static void snull_tx_timeout (struct net_device *dev)
{
	struct snull_priv *priv = netdev_priv(dev);
	
	//ģ�⴫���ж�
	priv->status = SNULL_TX_INTR;
	snull_interrupt(0, dev, NULL);
	priv->stats.tx_errors++;
	netif_wake_queue(dev);

	return;
}

static int snull_ioctl(struct net_device *dev, struct ifreq *rq, int cmd)
{
	printk("snullnet:snull_ioctl\n");
	return 0;
}

static struct net_device_stats *snull_stats(struct net_device *dev)
{
	struct snull_priv *priv = netdev_priv(dev);
	return &priv->stats;
}

static int snull_create_header(struct sk_buff *skb, struct net_device *dev,

                               unsigned short type, const void *daddr, 

                               const void *saddr, unsigned len)
{
	struct ethhdr *eth = (struct ethhdr *)skb_push(skb, ETH_HLEN);
	printk("snullnet:snull_create_header\n");
	eth->h_proto = htons(type);
	memcpy(eth->h_source, saddr ? saddr : dev->dev_addr, dev->addr_len);
	memcpy(eth->h_dest, daddr ? daddr : dev->dev_addr, dev->addr_len);
	eth->h_dest[ETH_ALEN - 1] ^= 1;
	
	return (dev->hard_header_len);
}

static int snull_rebuild_header(struct sk_buff *skb)
{
	struct ethhdr *eth = (struct ethhdr *)skb->data;
	struct net_device *dev = skb->dev;

	printk("snullnet:snull_rebuild_header\n");
	memcpy(eth->h_source, dev->dev_addr, dev->addr_len);
	memcpy(eth->h_dest, dev->dev_addr, dev->addr_len);
	eth->h_dest[ETH_ALEN - 1] ^= 1;
	
	return 0;
}

static int snull_change_mtu(struct net_device *dev, int new_mtu)
{
	unsigned long flags;
	struct snull_priv *priv = netdev_priv(dev);
	spinlock_t *lock = &priv->lock;

	printk("snullnet:snull_change_mtu\n");
	
	if((new_mtu < 68) || (new_mtu > 1500)) return -EINVAL;
	spin_lock_irqsave(lock, flags);
	dev->mtu = new_mtu;
	spin_unlock_irqrestore(lock, flags);

	return 0;
}

static struct header_ops snull_header_ops = 
{
	.create     = snull_create_header,
	.rebuild    = snull_rebuild_header,
};

static struct net_device_ops snulldev_ops = 
{
	.ndo_open               = snull_open,
	.ndo_stop               = snull_release,
	.ndo_set_config         = snull_config,
	.ndo_start_xmit         = snull_tx,
	.ndo_do_ioctl           = snull_ioctl,
	.ndo_get_stats          = snull_stats,
	.ndo_change_mtu         = snull_change_mtu,
	.ndo_tx_timeout         = snull_tx_timeout,
};

static void snull_rx_ints(struct net_device *dev, int enable)
{
	struct snull_priv *priv     = netdev_priv(dev);
	priv->rx_int_enabled         = enable;
}

static void snull_setup_pool(struct net_device *dev)
{
	struct snull_priv *priv = netdev_priv(dev);
	int i;
	struct snull_packet *pkt;

	printk("snullnet:snull_setup_pool\n");
	priv->ppool = NULL;
	
	for(i = 0; i < pool_size; i++) 
	{
		pkt = kmalloc(sizeof (struct snull_packet), GFP_KERNEL);
		if(NULL == pkt) 
		{
			printk(KERN_NOTICE "Ran out of memory allocating packet pool\n");
			return;
		}
		pkt->dev = dev;
		pkt->next = priv->ppool;
		priv->ppool = pkt;
	}
}

static void snull_release_buffer(struct snull_packet *pkt)
{
	unsigned long flags;
	struct snull_priv *priv = netdev_priv(pkt->dev);

	spin_lock_irqsave(&priv->lock, flags);
	pkt->next = priv->ppool;//ţ�ƣ��������ṹ�Ḵ�ó�

	priv->ppool = pkt;
	spin_unlock_irqrestore(&priv->lock, flags);

	if (netif_queue_stopped(pkt->dev) && pkt->next == NULL) 
	{
		netif_wake_queue(pkt->dev);
	}
}

static int snull_poll(struct napi_struct *napi, int work_limit)
{
	int nworked = 0;
	struct snull_priv *priv = netdev_priv(napi->dev);
	struct sk_buff *skb;
	struct snull_packet *pkt;
	unsigned long flags;

	printk("snullnet:work_limit = %d\n", work_limit);
	
	while(nworked < work_limit && priv->rx_queue) 
	{
		spin_lock_irqsave(&priv->lock, flags);
		pkt = priv->rx_queue;
		priv->rx_queue = priv->rx_queue->next;
		spin_unlock_irqrestore(&priv->lock, flags);
		skb = dev_alloc_skb(pkt->datalen + 2);
		
		if(!skb) 
		{
			//û�з��䵽�ڴ�
			priv->stats.rx_dropped++;
			snull_release_buffer(pkt);
			continue;
		}

		skb_reserve(skb, 2);
		memcpy(skb_put(skb, pkt->datalen), pkt->data, pkt->datalen);
		skb->dev = napi->dev;
		skb->protocol = eth_type_trans(skb, napi->dev);

		//skb->ip_summed = CHECKSUM_UNNECTSSARY;
		netif_receive_skb(skb);
		nworked++;
		priv->stats.rx_packets++;
		priv->stats.rx_bytes += pkt->datalen;
		snull_release_buffer(pkt);
	}
	//�ôε�poll���̽���
	if(!priv->rx_queue) 
	{
		//�Ѿ��������������ݰ�
		napi_complete(napi);
		snull_rx_ints(napi->dev, 1);
		//return 0;
	}

	return nworked;
}

static void snull_init(struct net_device *dev)
{
	struct snull_priv *priv;

	printk("snullnet:snull_init\n");
	priv = netdev_priv(dev);
	ether_setup(dev);
	dev->netdev_ops = &snulldev_ops;
	dev->header_ops = &snull_header_ops;

	if (use_napi) 
	{
		priv->snull_napi = kmalloc(sizeof (struct napi_struct), GFP_KERNEL);
		netif_napi_add(dev, priv->snull_napi, snull_poll, 16);
	}

	dev->flags                 |= IFF_NOARP;
	//dev->features             |= 
	//dev->hard_header_cache    = 
	
	memset(priv, 0, sizeof(struct snull_priv));
	spin_lock_init(&priv->lock);
	snull_rx_ints(dev, 1);
	snull_setup_pool(dev);
}

static void snull_rx(struct net_device *dev, struct snull_packet *pkt)
{
	struct sk_buff *skb;
	struct snull_priv *priv = netdev_priv(dev);

	printk("snullnet:snull_rx\n");
	skb = dev_alloc_skb(pkt->datalen + 2);

	if(!skb) 
	{
		priv->stats.rx_dropped++;
		goto out;
	}
	
	skb_reserve(skb, 2);

	memcpy(skb_put(skb, pkt->datalen), pkt->data, pkt->datalen);
	skb->dev = dev;
	skb->protocol = eth_type_trans(skb, dev);
	skb->ip_summed = CHECKSUM_UNNECESSARY;
	priv->stats.rx_packets++;
	priv->stats.rx_bytes += pkt->datalen;
	netif_rx(skb);
	
	out:
		return;
}

static void snull_napi_interrupt(int irq, void *dev_id, struct pt_regs *regs)
{
	int statusword;
	struct snull_priv *priv;
	struct net_device *dev = (struct net_device *)dev_id;
	
	printk("snull_napi_interrupt\n");
	if (!dev) 
		return;
	priv = netdev_priv(dev);
	spin_lock(&priv->lock);
	statusword = priv->status;
	priv->status = 0;                                                                                
	return;

	if(statusword & SNULL_RX_INTR) 
	{
		snull_rx_ints(dev, 0);//��ֹ�����ж�
		napi_enable(priv->snull_napi);
		napi_schedule(priv->snull_napi);
	}

	if (statusword & SNULL_TX_INTR) 
	{
		priv->stats.tx_packets++;
		priv->stats.tx_bytes += priv->tx_packetlen;
		kfree_skb(priv->skb);
	}

	spin_unlock(&priv->lock);

	return ;
}

static void snull_regular_interrupt(int irq, \
																		void *dev_id, struct pt_regs *regs) 
{
	int statusword;
	struct snull_priv *priv;
	struct snull_packet *pkt = NULL;
	struct net_device *dev = (struct net_device *)dev_id;

	if(!dev) 
		return;
	priv = netdev_priv(dev);
	spin_lock(&priv->lock);
	statusword = priv->status;
	priv->status = 0;

	if(statusword & SNULL_RX_INTR) 
	{
		pkt = priv->rx_queue;
		if(pkt) 
		{
			priv->rx_queue = pkt->next;
			snull_rx(dev, pkt);
		}
	}

	if(statusword & SNULL_TX_INTR) 
	{
		priv->stats.tx_packets++;
		priv->stats.tx_bytes += priv->tx_packetlen;
		dev_kfree_skb(priv->skb);
	}

	spin_unlock(&priv->lock);
	if(pkt) 
		snull_release_buffer(pkt);
	return;
}

static void snull_free_pool(struct net_device *dev)
{
	int i;
	struct snull_priv *priv = netdev_priv(dev);
	struct snull_packet *pkt;

	for(i = 0; i < pool_size; i++) 
	{
		pkt = priv->ppool;
		priv->ppool = pkt->next;
		kfree(pkt);
	}
}
static void snullnet_clean(void)
{
	int i;
	struct snull_priv *priv;

	printk(KERN_ALERT "snullnet exiting");

	for(i = 0;i < 2; i++) 
	{
		if(snull_dev[i]) 
		{
			unregister_netdev(snull_dev[i]);
			snull_free_pool(snull_dev[i]);
			priv = netdev_priv(snull_dev[i]);
			kfree(priv->snull_napi);
			free_netdev(snull_dev[i]);    
		}
	}
}

static int __init snullnet_init(void)
{
	int i, ret = 0;

	printk(KERN_ALERT "snullnet initing");
	snull_interrupt = use_napi ? snull_napi_interrupt : \
                               snull_regular_interrupt;
	
	for(i = 0; i < 2; i++) 
	{                                                    //�����豸
		snull_dev[i] = alloc_netdev(sizeof(struct snull_priv), "sn%d", snull_init);
	}

	if(!snull_dev[0] || !snull_dev[1]) 
	{
		ret = -ENOMEM;
		goto out;
	}

	for(i = 0; i < 2; i++) 
	{                                                  //ע���豸
		int ret = 0;
		if((ret = register_netdev(snull_dev[i]))) 
		{
			printk(KERN_ALERT "snull: error %i registering device \
                                         \"%s\"\n", ret, snull_dev[i]->name);
			goto out;
		}
	}

	return 0;
	
	out:
		snullnet_clean();
		return ret;
}

module_init(snullnet_init);

module_exit(snullnet_clean);

