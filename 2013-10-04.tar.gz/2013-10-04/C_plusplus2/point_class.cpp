#include "iostream"
using namespace std;

class Point
{
	public:
		Point(int xx=0,int yy=0) 
			{
				X=xx;
				Y=yy;
			}
		Point(Point &p);
		int getx()
			{
				return X;
			}
		int gety()
			{
				return Y;
			}
	private:
		int X,Y;
};

Point::Point(Point &p)
{
	X=p.X;
	Y=p.Y;
	cout<<"拷贝构造函数被调用"<<endl;
}

void fun1(Point p)
{
	cout<<p.getx()<<endl;
}


Point fun2()
{
	Point A(1,2);
	return A;
}


int main()
{
	Point A(4,5);
	Point B(A);
	cout<<B.getx()<<endl;
	fun1(B);
	B=fun2();
	cout<<B.getx()<<endl;
}
	









