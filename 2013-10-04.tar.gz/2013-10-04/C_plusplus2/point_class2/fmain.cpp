#include "point.h"

int Point::countp=0;

int main()
{
	Point a(4,5);
        cout<<"point a,x="<<a.getx()<<"    "<<"point a,y="<<a.gety()<<endl;
	a.getc();
	cout<<endl;
	Point b(a);
	cout<<"point b,x="<<b.getx()<<"    "<<"point b,y="<<b.gety()<<endl;
	cout<<endl;
	Point::getc();
}
