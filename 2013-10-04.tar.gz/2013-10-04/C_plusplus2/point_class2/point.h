#include "iostream"
using namespace std;

class Point
{
	public:
		Point(int xx=0,int yy=0) 
			{
				X=xx;
				Y=yy;
				countp++;
			}
		Point(Point &p);
		int getx()
			{
				return X;
			}
		int gety()
			{
				return Y;
			}
		static void getc()
			{	
				cout<<"Object id="<<countp<<endl;
			}

	private:
		int X,Y;
		static int countp;
};


Point::Point(Point &p)
{
	X=p.X;
	Y=p.Y;
	countp++;
}
