#include "iostream"
using namespace std;

const float pi=(float)3.14159;
const float fence_price=(float)35.0;
const float concrete_price=(float)20.0;

class Circle
{
	public:
		Circle(float r);
		float circumference();
		float area();
	private:
		float radius;
};

Circle::Circle(float r)
{
	radius=r;
}

float Circle::circumference()
{
	return 2*pi*radius;
}

float Circle::area()
{
	return pi*radius*radius;
}


int main()
{
	float radius;
	float fence_cost,concrete_cost;
	


	cout<<"Enter the radius of the pool:";
	cin>>radius;
	Circle pool(radius);
        Circle pool_rim(radius+3);


	fence_cost=pool_rim.circumference()*fence_price;
	cout<<"Fencing Cost is "<<fence_cost<<endl;


	concrete_cost=(pool_rim.area()-pool.area())*concrete_price;
	cout<<"Concrete Cost is "<<concrete_cost<<endl;
}






















