#include "iostream"
using namespace std;

class Clock
{
	public:
		void settime(int newh=0,int newm=0,int news=0);
		void showtime();
	private:
		int hour,minute,second;
};

void Clock::settime(int newh,int newm,int news)
{
	hour=newh;
	minute=newm;
	second=news;
}

inline void Clock::showtime()
{
	cout<<hour<<":"<<minute<<":"<<second<<endl;
}

int main()
{
	Clock myclock;
	cout<<"First time set and output:"<<endl;
	myclock.settime();
	myclock.showtime();
	cout<<"Second time set and output:"<<endl;
	myclock.settime(8,30,30);
	myclock.showtime();
}

