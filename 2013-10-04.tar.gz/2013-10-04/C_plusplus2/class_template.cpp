#include "iostream"
#include "stdlib"
using namespace std;

struct student
{
	int id;
	float gpa;
};

template <class T>
class Store
{
	private:
		T item;
		int have_value;
	public:
		Store(void);
		T get_elem(void);
		void put_elem(T x);
};

template <class T>
Store<T>::Store(void):have_value(0)
{
}

template <class T>
T Store<T>::get_elem(void)
{
	if(have_value==0)
	{
		cout<<"No item present!"<<endl;
		exit(1);
	}
	return item;
}

template <class T>
void Store<T>::put_elem(T x)
{
	have_value++;
	item=x;
}



int main()
{
	student g={1000,23};
	Store<int> s1,s2;
        Store<student> s3;
        Store<double> d;

	s1.put_elem(3);
	s2.put_elem(-7);
 	cout<<s1.get_elem()<<" "<<s2.get_elem()<<endl;

	s3.put_elem(g);
 	cout<<"The student id is "<<s3.get_elem()<<endl;


	cout<<"Retrieving object d ";
	cout<<d.get_elem()<<endl;
}












