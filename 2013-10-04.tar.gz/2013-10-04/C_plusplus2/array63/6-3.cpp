
#include "location.h"


int main()
{
	cout<<"Entering main..."<<endl;
	Location a[2];
	for(int i=0;i<2;i++)
		a[i].move(i+10,i+20);
	cout<<"Exiting main..."<<endl;
}
