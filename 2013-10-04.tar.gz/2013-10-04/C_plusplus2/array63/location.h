#ifndef LOCATION_H
#define LOCATION_H
#include "iostream"
using namespace std;

class Location
{
	
	public:
		Location();
		Location(int xx,int yy);
		~Location();
		void move(int x,int y);
		int getx()
		{
			return X;
		}
		int gety()
		{
			return Y;
		}
	private:
		int X,Y;
};

Location::Location()
{
	X=Y=0;
	cout<<"Default Constructor called."<<endl;
}

Location::Location(int xx,int yy)
{
	X=xx;
	Y=yy;
	cout<<"Constructor called."<<endl;
}

Location::~Location()
{
	
	cout<<"Destructor called."<<endl;
}


void Location::move(int x,int y)
{
	X=x;
	Y=y;
	
}
#endif
