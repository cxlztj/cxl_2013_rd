#include "iostream"
#include "math.h"
using namespace std;

class Point
{
	public:
		Point(int xx=0,int yy=0) 
			{
				X=xx;
				Y=yy;
			}
		Point(Point &p);
		int getx()
			{
				return X;
			}
		int gety()
			{
				return Y;
			}
	private:
		int X,Y;
};

Point::Point(Point &p)
{
	X=p.X;
	Y=p.Y;
	cout<<"Point拷贝构造函数被调用"<<endl;
}

class Distance 
{
	public:
		Distance(Point xp1,Point xp2);
		double get_dis() 
		{
			return dist;
		}
	private:
		Point p1,p2;
		double dist;
};

Distance::Distance(Point xp1,Point xp2)
:p1(xp1),p2(xp2)
{
	cout<<"Distance构造函数被调用 "<<endl;
	double x=double(p1.getx()-p2.getx());
	double y=double(p1.gety()-p2.gety());
	dist=sqrt(x*x+y*y);
}


int main()
{
	Point myp1(1,1),myp2(4,5);
	Distance myd(myp1,myp2);
	cout<<"The distance is:";
	cout<<myd.get_dis()<<endl;
}


















