#include "iostream"
//#include "math.h"
using namespace std;

class Point
{
	public:
		Point(float xx=0,float yy=0) 
			{
				X=xx;
				Y=yy;
				
			}
		
		float getx()
			{
				return X;
			}
		float gety()
			{
				return Y;
			}
		friend float linefit(Point l_point[],int n_point);
	private:
		float X,Y;
		
};






