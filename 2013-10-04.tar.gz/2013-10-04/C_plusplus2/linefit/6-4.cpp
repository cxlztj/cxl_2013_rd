#include "math.h"
#include "point.h"

float linefit(Point l_point[],int n_point)
{
	float av_x,av_y;
	float L_XX,L_YY,L_XY;

	av_x=0;
	av_y=0;
	L_XX=0;
	L_YY=0;
	L_XY=0;
	int i;

//	for(i=0;i<n_point;i++)
//av_x += (1_point[0].X)/n_point;
//		av_y +=1_point[i].Y/n_point;
//	}

	for(i=0;i<n_point;i++)
	{
		L_XX+=(1_point[i].X-av_x)*(1_point[i].X-av_x);
		L_YY+=(1_point[i].Y-av_y)*(1_point[i].Y-av_y);
		L_XY+=(1_point[i].X-av_x)*(1_point[i].Y-av_y);
	}

	cout<<"This line can be fitted by y=ax+b."<<endl;
	cout<<"a="<<L_XY/L_XX;
	cout<<"b="<<av_y-L_XY*av_x/L_XX<<endl;
	return float(L_XY/sqrt(L_XX*L_YY));
	//return L_YY;
	
}

int main()
{
	Point l_p[10]={
			Point(6,10),
			Point(14,20),
			Point(26,30),
			Point(33,40),
			Point(46,50),
			Point(54,60),
			Point(67,70),
			Point(75,80),
			Point(84,90),
			Point(100,100)
			};
	//float r=linefit(l_p,10);
	//cout<<"Line coefficient r="<<r<<endl;
	cout<<"Line coefficient r="<<endl;
}




