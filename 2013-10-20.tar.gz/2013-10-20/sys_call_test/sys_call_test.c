#include <linux/unistd.h>
#include <sys/syscall.h>

#define __NR_getjiffies		320

int main()
{
  long jiffies;

  jiffies = syscall( __NR_getjiffies );

  printf( "Current jiffies is %lx\n", jiffies );

  return 0;
}
