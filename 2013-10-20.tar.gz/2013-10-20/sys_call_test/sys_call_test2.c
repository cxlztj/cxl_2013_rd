#include <linux/unistd.h>
#include <sys/syscall.h>

#define __NR_exit		1

int main()
{
  syscall( __NR_exit);

  

  return 0;
}
