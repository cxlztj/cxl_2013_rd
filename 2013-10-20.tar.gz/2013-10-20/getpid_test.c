/* getpid_test.c */
#include <unistd.h>
main()
{
	//while(1)
	//{
		printf("The current process ID is %d\n",getpid());
	//}
}
