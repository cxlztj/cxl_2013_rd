/* fork_test.c */
#include <sys/types.h>
#include <unistd.h>
#include <sys/resource.h>
#define PRIORITY 30
main()
{
	pid_t pid;
	
	
	pid=fork();
	
	if(pid<0)
		printf("error in fork!");
	else if(pid==0)
		{
			printf("I am the child process, my process ID is %d\n",getpid());
			setpriority(PRIO_PROCESS,getpid(),PRIORITY);
		}
	else
		printf("I am the parent process, my process ID is %d\n",getpid());
}
