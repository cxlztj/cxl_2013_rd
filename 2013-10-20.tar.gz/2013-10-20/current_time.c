#include <time.h>
int main()
{
 time_t time_raw_format;
 time ( &time_raw_format ); 
 printf (" time is [%d]\n", time_raw_format);
 
 printf ( "The current local time: %s", ctime(&time_raw_format));
 return 0;
}
