#include <stdio.h>
#include <openssl/evp.h>

int do_crypt(FILE *in, FILE *out, int do_encrypt);
int main(int argc,char **argv)
{
        FILE * fin;
        FILE * fout;
        fin = fopen(argv[1], "a+");
        fout = fopen(argv[2], "a+");
        do_crypt(fin, fout, atoi(argv[3]));
        return 0;
}
int do_crypt(FILE *in, FILE *out, int do_encrypt)
{
        char inbuf[1024], outbuf[1024 + EVP_MAX_BLOCK_LENGTH];
        int inlen, outlen;
        EVP_CIPHER_CTX ctx;
        unsigned char key[] = "0123456789";
        unsigned char iv[] = "12345678";
        /* ��ʱ�򲻽���key��IV�����ã���Ϊ���ǻ�Ҫ�޸Ĳ��� */
        EVP_CIPHER_CTX_init(&ctx);
        EVP_CipherInit_ex(&ctx, EVP_rc4(), NULL, NULL, NULL, do_encrypt);
        EVP_CIPHER_CTX_set_key_length(&ctx, 10);
        /* ��ɲ������ã�����key��IV������ */
        EVP_CipherInit_ex(&ctx, NULL, NULL, key, iv, do_encrypt);

        for(;;) 
          {
                inlen = fread(inbuf, 1, 1024, in);
                if(inlen <= 0) break;
                if(!EVP_CipherUpdate(&ctx, outbuf, &outlen, inbuf, inlen))
                  {
                        /*�������� */
                        return 0;
                  }
                fwrite(outbuf, 1, outlen, out);
          }

        if(!EVP_CipherFinal_ex(&ctx, outbuf, &outlen))
          {
                /* ��������*/
                return 0;
          }
        fwrite(outbuf, 1, outlen, out);
        EVP_CIPHER_CTX_cleanup(&ctx);
        return 1;
}

