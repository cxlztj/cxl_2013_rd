Linux Device Drivers, 2nd Edition

Examples

You may also retrieve this book's examples from the authors' Web site 
at ftp://ar.linux.it/pub/ldd2/ .