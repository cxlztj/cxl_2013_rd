#include "stdio.h"
 
static int i = 1;
 
 
 //void c_add(int *k)
 //{
 //    (*k)++;
 //} 
 //extern int a_add(int);
 int main(void)
 {    
     int j;     
     j=a_add(&i);
     printf("i=%d\n",i);
     printf("j=%d\n",j);
     //return 0;
 }

