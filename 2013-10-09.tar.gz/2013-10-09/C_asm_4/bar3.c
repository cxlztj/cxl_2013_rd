//bar.c 
#include "stdio.h"
//#include "stdlib.h"  
                                                                                                                                         
extern int addi(int);
//int addi(int i)
//{
//	return i++;
//}
int main()
{
    int i=1,j=0;  
    j=addi(i);
    //printf("j=%d\n",j);
    
    return 0;
}
