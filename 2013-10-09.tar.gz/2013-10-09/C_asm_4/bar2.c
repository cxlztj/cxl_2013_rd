//bar.c 
//#include "stdio.h"
//#include "stdlib.h"  
                                                                                                                                         
extern void myprint(void);
//int addi(int i)
//{
//	return i++;
//}
int main()
{
       
    myprint();
    //printf("j=%d\n",j);
    
    return 0;
}
