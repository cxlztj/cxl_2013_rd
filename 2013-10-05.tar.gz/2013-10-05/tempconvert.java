import java.io.*;
public class tempconvert
{
	public static void main(String args[]) throws IOException
	{
		BufferedReader buff=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Please input degrees in Celsius :");
		String input=buff.readLine();
		double c=Double.parseDouble(input);
		double f=9*c/5+32;
		System.out.println("Degrees in Fahrenheit is :"+f);
	}
}
