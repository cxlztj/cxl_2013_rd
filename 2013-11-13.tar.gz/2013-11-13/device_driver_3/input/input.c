#include <linux/input.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/interrupt.h>      //chen xiaolong add

#include <asm/irq.h>
#include <asm/io.h>

#define BUTTON_IRQ 122
#define BUTTON_PORT 0x9            //chen xiaolong add

static struct input_dev *button_dev;

static void button_interrupt(int irq, void *dummy, struct pt_regs *fp)
{
        input_report_key(&button_dev, BTN_1, inb(BUTTON_PORT) & 1);
        input_sync(&button_dev);
}
 
static int __init button_init(void)
{
	    
	if (request_irq(BUTTON_IRQ, button_interrupt, 0, "button", NULL)) { 
                  printk(KERN_ERR "button.c: Can't allocate irq %d\n", BUTTON_IRQ);       //chen xiaolong update    
                  return -EBUSY;
        }
 
        button_dev=input_allocate_device();                                               //chen xiaolong update 
        button_dev->evbit[0] = BIT_MASK(EV_KEY);                                          //chen xiaolong update 
        button_dev->keybit[BIT_WORD(BTN_0)] = BIT_MASK(BTN_0);                                //chen xiaolong update 
 
        input_register_device(&button_dev);
}
 
static void __exit button_exit(void)
{
        input_unregister_device(&button_dev);
        free_irq(BUTTON_IRQ, button_interrupt);
}
 
module_init(button_init);
module_exit(button_exit);
