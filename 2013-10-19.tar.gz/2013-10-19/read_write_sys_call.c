#include <stdio.h>
#include <unistd.h>

int main()
{
	char outs[200];
	int n;

	n=read(STDIN_FILENO,outs,200);
        if(n<0)
		perror("Error:");
	else
		write(STDOUT_FILENO,outs,n);
	return 0;
}
