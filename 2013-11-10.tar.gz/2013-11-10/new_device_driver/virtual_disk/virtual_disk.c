/*======================================================================
    A virtual_disk driver as an example of char device drivers  
   
======================================================================*/
#include <linux/module.h>
#include <linux/types.h>
#include <linux/fs.h>
#include <linux/errno.h>
#include <linux/mm.h>
#include <linux/sched.h>
#include <linux/init.h>
#include <linux/cdev.h>
#include <asm/io.h>
#include <asm/system.h>
#include <asm/uaccess.h>

#define VIRTUALDISK_SIZE	0x2000	
#define MEM_CLEAR 0x1  
#define PORT1_SET 0x2  
#define PORT2_SET 0x3  
/*
#define VirtualDisk_MAGIC 100
#define MEM_CLEAR _IO(VirtualDisk_MAGIC,0)
#define PORT1_SET _IO(VirtualDisk_MAGIC,1)
#define PORT2_SET _IO(VirtualDisk_MAGIC,2)
*/
#define VIRTUALDISK_MAJOR 201    

static int VirtualDisk_major = VIRTUALDISK_MAJOR;

struct VirtualDisk                                     
{                                                        
  struct cdev cdev;                       
  unsigned char mem[VIRTUALDISK_SIZE]; 
  int port1; 
  long port2;
  long count;  
};

struct VirtualDisk *Virtualdisk_devp; 

int VirtualDisk_open(struct inode *inode, struct file *filp)
{
 
  filp->private_data = Virtualdisk_devp;
  struct VirtualDisk *devp = filp->private_data;
  devp->count++;
  return 0;
}

int VirtualDisk_release(struct inode *inode, struct file *filp)
{
  struct VirtualDisk *devp = filp->private_data;
  devp->count--;
  return 0;
}


static int VirtualDisk_ioctl(struct inode *inodep, struct file *filp, unsigned
  int cmd, unsigned long arg)
{
  struct VirtualDisk *devp = filp->private_data;

  switch (cmd)
  {
    case MEM_CLEAR:
      memset(devp->mem, 0, VIRTUALDISK_SIZE);      
      printk(KERN_INFO "VirtualDisk is set to zero\n");
      break;
	case PORT1_SET:
	  devp->port1=0;
	  break;
	case PORT2_SET:
	  devp->port2=0;
	  break;
    default:
      return  - EINVAL;
  }
  return 0;
}


static ssize_t VirtualDisk_read(struct file *filp, char __user *buf, size_t size,
  loff_t *ppos)
{
  unsigned long p =  *ppos; 
  unsigned int count = size;
  int ret = 0;
  struct VirtualDisk *devp = filp->private_data;

  
  if (p >= VIRTUALDISK_SIZE)  
    return count ?  - ENXIO: 0;
  if (count > VIRTUALDISK_SIZE - p)
    count = VIRTUALDISK_SIZE - p;
  
  if (copy_to_user(buf, (void*)(devp->mem + p), count))
  {
    ret =  - EFAULT;
  }
  else
  {
    *ppos += count;
    ret = count;
    printk(KERN_INFO "read %d bytes(s) from %d\n", count, p);
  }
  return ret;
}


static ssize_t VirtualDisk_write(struct file *filp, const char __user *buf,
  size_t size, loff_t *ppos)
{
  unsigned long p =  *ppos; 
  int ret = 0;  
  unsigned int count = size;
  struct VirtualDisk *devp = filp->private_data;
  
  
  if (p >= VIRTUALDISK_SIZE)
    return count ?  - ENXIO: 0;
  if (count > VIRTUALDISK_SIZE - p)
    count = VIRTUALDISK_SIZE - p;
    
  
  if (copy_from_user(devp->mem + p, buf, count))
    ret =  - EFAULT;
  else
  {
    *ppos += count;
    ret = count;
    printk(KERN_INFO "written %d bytes(s) from %d\n", count, p);
  }
  return ret;
}


static loff_t VirtualDisk_llseek(struct file *filp, loff_t offset, int orig)
{
  loff_t ret = 0;
  switch (orig)
  {
    case SEEK_SET:   
      if (offset < 0)
      {
        ret =  - EINVAL;		
        break;
      }
      if ((unsigned int)offset > VIRTUALDISK_SIZE)
      {
        ret =  - EINVAL;		
        break;
      }
      filp->f_pos = (unsigned int)offset;	
      ret = filp->f_pos;
      break;
    case SEEK_CUR:   
      if ((filp->f_pos + offset) > VIRTUALDISK_SIZE)
      {
        ret =  - EINVAL;
        break;
      }
      if ((filp->f_pos + offset) < 0)
      {
        ret =  - EINVAL;
        break;
      }
      filp->f_pos += offset;
      ret = filp->f_pos;
      break;
    default:
      ret =  - EINVAL;
      break;
  }
  return ret;
}


static const struct file_operations VirtualDisk_fops =
{
  .owner = THIS_MODULE,
  .llseek = VirtualDisk_llseek,
  .read = VirtualDisk_read,
  .write = VirtualDisk_write,
  .ioctl = VirtualDisk_ioctl,
  .open = VirtualDisk_open,
  .release = VirtualDisk_release,
};


static void VirtualDisk_setup_cdev(struct VirtualDisk *dev, int minor)
{
  int err;
  dev_t devno = MKDEV(VirtualDisk_major, minor);
  cdev_init(&dev->cdev, &VirtualDisk_fops);
  dev->cdev.owner = THIS_MODULE;
  dev->cdev.ops = &VirtualDisk_fops;
  err = cdev_add(&dev->cdev, devno, 1);
  if (err)
    printk(KERN_NOTICE "Error in cdev_add()\n");
}

int VirtualDisk_init(void)
{
  int result;
  dev_t devno = MKDEV(VirtualDisk_major, 0); 

  
  if (VirtualDisk_major)  
    result = register_chrdev_region(devno, 1, "VirtualDisk");
  else  
  {
    result = alloc_chrdev_region(&devno, 0, 1, "VirtualDisk");
    VirtualDisk_major = MAJOR(devno);
  }  
  if (result < 0)
    return result;
    
  
  Virtualdisk_devp = kmalloc(sizeof(struct VirtualDisk), GFP_KERNEL);
  if (!Virtualdisk_devp)    
  {
    result =  - ENOMEM;
    goto fail_kmalloc;
  }
  memset(Virtualdisk_devp, 0, sizeof(struct VirtualDisk));
  
  VirtualDisk_setup_cdev(Virtualdisk_devp, 0);
  return 0;

  fail_kmalloc:
  unregister_chrdev_region(devno, 1);
  return result;
}


void VirtualDisk_exit(void)
{
  cdev_del(&Virtualdisk_devp->cdev);   
  kfree(Virtualdisk_devp);     
  unregister_chrdev_region(MKDEV(VirtualDisk_major, 0), 1); 
}

MODULE_AUTHOR("Chen Xiaolong");
MODULE_LICENSE("Dual BSD/GPL");

module_param(VirtualDisk_major, int, S_IRUGO);

module_init(VirtualDisk_init);
module_exit(VirtualDisk_exit);
