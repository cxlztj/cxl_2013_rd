/*
 * File Name: virtual_disk_test.c
 */
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>

void main()
{
   int fileno;
   int number;
   char data[]="one two three four five six";
   char str[1024];
   int len;

   fileno = open("/dev/virtual_disk",O_RDWR);

   if (fileno == -1)
   {
   	printf("open virtual_disk device errr!\n");
	return 0;
   }
    
   write(fileno,data,strlen(data));
   close(fileno);

   fileno=open("/dev/virtual_disk",O_RDWR);
   len=read(fileno,str,1024);
   str[len]='\0';
   printf("%s\n",str);
   close(fileno);
   
   fileno=open("/dev/virtual_disk",O_RDWR);
   lseek(fileno,4,SEEK_SET);
   len=read(fileno,str,1024);
   str[len]='\0';
   printf("%s\n",str);
   close(fileno);

   return 0;
}
