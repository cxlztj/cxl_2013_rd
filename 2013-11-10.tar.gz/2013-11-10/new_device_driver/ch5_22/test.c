/*test.c  chen xiaolong*/
#include <linux/fs.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>




#include <sys/time.h>
#include <unistd.h>

int main()
{
/*
	char buffer[64];
	int count;
	int fd;
	char inputbuffer[64],outputbuffer[64];
	fd = open("/dev/driver", O_RDWR);
	read(fd, buffer, 64);
	printf("%s", buffer);

        scanf("%s",inputbuffer);
        printf("Input: %s.\n", inputbuffer);
        write(fd,inputbuffer,64);
        
	read(fd,outputbuffer,64);
        printf("Read from Kernel: %s.\n", outputbuffer);
	close(fd);
        exit(0);
	return 0;
*/


	char buffer[64];
	int len;
	int fd;
	char inputbuffer[64],outputbuffer[64];

	fd = open("/dev/driver", O_RDWR);
	read(fd, buffer, 64);
    	printf("%s", buffer);
        close(fd);


	return 0;



}
