#define READ_COMMAND 3   /*First argument to syslog() system call*/
#define MSG_LENGTH 128   /*Third argument to syslog()*/

int main(int argc,char *argv[])
{
	int syslog_command=READ_COMMAND;
	int bytes_to_read=MSG_LENGTH;
	int retval;
	char buffer[MSG_LENGTH];  /*Second argument to syslog()*/

	asm volatile(
		"movl %1,%%ebx\n"          /*First argument to syslog() */
		"movl %2,%%ecx\n"          /*Second argument to syslog()*/
		"movl %3,%%edx\n"          /*Third argument to syslog()*/
		"movl $103,%%eax\n"        /*__NR_syslog*/
		"int $128\n"               /*equal to int 0x80,generate sys call*/
		"movl %%eax,%0\n"          /*eax-->retval*/
		:"=r"(retval)              /*return value of sys call*/
		:"m"(syslog_command),"r"(buffer),"m"(bytes_to_read)
		:"%eax","%ebx","%ecx","%edx");
	if(retval>0) 
		printf("%s\n",buffer);
}
