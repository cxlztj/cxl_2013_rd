#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("chen xiaolong");
MODULE_DESCRIPTION("This is an example of module.!");
MODULE_ALIAS("a simplest module");

static int hello_module_init(void)
{
//	printk(KERN_ALERT "Hello World enter!\n");
	printk(KERN_EMERG "Hello World enter!\n");

	return 0;
}

static void hello_module_exit(void)
{
//	printk(KERN_ALERT "Hello world exit!\n");
	printk(KERN_EMERG "Hello world exit!\n");
}
module_init(hello_module_init);
module_exit(hello_module_exit);
