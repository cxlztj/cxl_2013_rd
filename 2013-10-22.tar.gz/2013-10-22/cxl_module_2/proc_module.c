#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/sched.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/types.h>
#include <linux/slab.h>
//#include <linux/sys/types.h>
//#include <linux/unistd.h>
//#include <stdio.h>
//#include <stdlib.h>
//#include <string.h>
//#include <linux/proc_fs.h>
#include <asm/uaccess.h>
#include <linux/pci.h>


MODULE_LICENSE("GPL");
MODULE_AUTHOR("chen xiaolong");
MODULE_DESCRIPTION("This is an example of module.!");
MODULE_ALIAS("a simplest module");

static int proc_module_init(void)
{
//	printk(KERN_ALERT "Hello World enter!\n");
	int r;
	struct task_struct *p=NULL;
	r=fork();
	if(!r)
	{
		printk("P1 pid=%d,path=%s\n",current->pid,current->comm);
		p=list_entry(current->tasks.next,struct task_struct,tasks);
		printk("P2 pid=%d,path=%s\n",p->pid,p->comm);
	}

	return 0;
}

static void proc_module_exit(void)
{
//	printk(KERN_ALERT "Hello world exit!\n");
	printk("The module is finished!\n");
}
module_init(proc_module_init);
module_exit(proc_module_exit);
