 
 char version[] = "servfox version: 1.1.2 date: 07:10:2005 (C) mxhaard@magic.fr\0";
