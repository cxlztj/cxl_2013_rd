 
 char version[] = "Spcaview version: 1.1.7 date: 06:11:2006 (C) mxhaard@magic.fr\0";
