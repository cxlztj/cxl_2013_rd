#include "stdio.h"
char buff[256];
char * string;

int main()
{
	printf("please input a string:");
	gets(string);
	printf("\nYour string is : %s\n",string);
}
