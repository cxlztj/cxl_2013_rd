#include "iostream"
using namespace std;
int main()
{
	float c,f;
	cout<<"Please input degrees in Celsius:";
	cin>>c;
	f=9*c/5+32;
	cout<<"Degrees in Fahrenheit is : "<<f<<endl;
}
