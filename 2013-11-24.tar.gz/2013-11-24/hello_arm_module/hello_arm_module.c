/*
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file "COPYING" in the main directory of this archive
 * for more details.
 * Copyright (C) 2013, 2013 chen xaiolong(cxlztj@126.com)
 */

#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/module.h>

static int hello_init(void)
{ 
    printk("Hello, Mini2440! This is the first test module!\n");
    return 0;
}

static void hello_exit(void)
{
      printk("Mini2440, Bye Bye!\n");
      return;
}

module_init(hello_init);
module_exit(hello_exit);

MODULE_AUTHOR("cxl");
MODULE_LICENSE("Dual BSD/GPL");

